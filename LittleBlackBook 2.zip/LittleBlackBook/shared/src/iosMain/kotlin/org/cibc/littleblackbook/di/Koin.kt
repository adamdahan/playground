package org.cibc.littleblackbook.di

import org.koin.mp.KoinPlatform
import org.cibc.littleblackbook.UserPresenter

fun getUserPresenter() : UserPresenter = KoinPlatform.getKoin().get()