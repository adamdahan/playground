package org.cibc.littleblackbook.di

import org.koin.core.module.dsl.bind
import org.koin.core.module.dsl.factoryOf
import org.koin.core.module.dsl.singleOf
import org.koin.dsl.module
import org.cibc.littleblackbook.UserPresenter
import org.cibc.littleblackbook.data.FinancialTransactionRepository
import org.cibc.littleblackbook.data.FinancialTransactionRepositoryImpl
import org.cibc.littleblackbook.data.UserRepository
import org.cibc.littleblackbook.data.UserRepositoryImpl

val appModule = module {
    singleOf(::UserRepositoryImpl) { bind<UserRepository>() }
    singleOf(::FinancialTransactionRepositoryImpl) { bind<FinancialTransactionRepository>() }
    factoryOf(::UserPresenter)
}