package org.cibc.littleblackbook.data

// Define the FinancialTransaction data class
data class FinancialTransaction(val id: String, val amount: Double)

// Define the FinancialTransactionRepository interface
interface FinancialTransactionRepository {
    fun findTransactionById(id: String): FinancialTransaction?
    fun addTransactions(transactions: List<FinancialTransaction>)
    fun updateTransaction(transaction: FinancialTransaction): Boolean
    fun deleteTransactionById(id: String): Boolean
    fun getAllTransactions(): List<FinancialTransaction>
}

// Implement the FinancialTransactionRepository interface
class FinancialTransactionRepositoryImpl : FinancialTransactionRepository {

    private val _transactions = arrayListOf<FinancialTransaction>()

    override fun findTransactionById(id: String): FinancialTransaction? {
        return _transactions.firstOrNull { it.id == id }
    }

    override fun addTransactions(transactions: List<FinancialTransaction>) {
        _transactions.addAll(transactions)
    }

    override fun updateTransaction(transaction: FinancialTransaction): Boolean {
        val index = _transactions.indexOfFirst { it.id == transaction.id }
        return if (index != -1) {
            _transactions[index] = transaction
            true
        } else {
            false
        }
    }

    override fun deleteTransactionById(id: String): Boolean {
        val iterator = _transactions.iterator()
        while (iterator.hasNext()) {
            if (iterator.next().id == id) {
                iterator.remove()
                return true
            }
        }
        return false
    }

    override fun getAllTransactions(): List<FinancialTransaction> {
        return _transactions
    }
}