package org.cibc.littleblackbook.data

data class User(val name : String)