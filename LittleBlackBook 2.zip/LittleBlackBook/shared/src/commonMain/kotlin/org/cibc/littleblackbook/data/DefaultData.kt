package org.cibc.littleblackbook.data

object DefaultData {
    val DEFAULT_USER = User("Koin")
    val DEFAULT_USERS = listOf(DEFAULT_USER)
}