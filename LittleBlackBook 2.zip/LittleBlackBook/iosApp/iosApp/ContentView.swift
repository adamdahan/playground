import SwiftUI
import Shared

struct CurrencyToolbarListView: View {
    
    let greet = KoinKt.getUserPresenter().sayHello(name: "Koin")
    
    @State private var transactions: [Transaction] = []
    @State private var showTransactionModal: Bool = false
    @State private var editingTransaction: Transaction? = nil
    @State private var transactionType: Transaction.TransactionType = .credit

    private var totalAmount: Double {
        transactions.reduce(0) { total, transaction in
            switch transaction.type {
            case .credit: return total + transaction.amount
            case .debit: return total - transaction.amount
            }
        }
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                CurrencyDisplayView(amount: totalAmount)
                    .frame(height: 200)
                    .padding([.leading, .trailing])
                List {
                    ForEach(transactions) { transaction in
                        TransactionRowView(transaction: transaction)
                            .onTapGesture {
                                // Open editing modal
                                editingTransaction = transaction
                                transactionType = transaction.type
                                showTransactionModal = true
                            }
                            .swipeActions {
                                Button(role: .destructive) {
                                    withAnimation {
                                        transactions.removeAll { $0.id == transaction.id }
                                    }
                                } label: {
                                    Label("Delete", systemImage: "trash")
                                }
                            }
                    }
                }
                Spacer()
            }
            .offset(y: -80)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        transactionType = .debit
                        editingTransaction = nil // Clear editing mode
                        showTransactionModal = true
                    }) {
                        Image(systemName: "minus.circle")
                            .font(.title)
                            .foregroundColor(.red)
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        transactionType = .credit
                        editingTransaction = nil // Clear editing mode
                        showTransactionModal = true
                    }) {
                        Image(systemName: "plus.circle")
                            .font(.title)
                            .foregroundColor(.green)
                    }
                }
            }
            .sheet(isPresented: $showTransactionModal) {
                TransactionEntryView(transactionType: transactionType, editingTransaction: $editingTransaction) { transaction in
                    if let editingTransaction = editingTransaction {
                        // Update an existing transaction
                        if let index = transactions.firstIndex(where: { $0.id == editingTransaction.id }) {
                            transactions[index] = transaction
                        }
                    } else {
                        // Add a new transaction
                        transactions.append(transaction)
                    }
                }
            }
        }
    }
}

// Modal view for adding or editing a transaction
struct TransactionEntryView: View {
    let transactionType: Transaction.TransactionType
    @Binding var editingTransaction: Transaction?
    @Environment(\.dismiss) private var dismiss
    @State private var inputAmount: String = ""
    var onSave: (Transaction) -> Void
    
    var body: some View {
        NavigationView {
            VStack {
                TextField("Enter amount", text: $inputAmount)
                    .keyboardType(.decimalPad)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                Spacer()
            }
            .navigationTitle(editingTransaction != nil ? "Edit Transaction" : transactionType == .credit ? "Add Credit" : "Add Debit")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        if let amount = Double(inputAmount), amount > 0 {
                            let transaction = Transaction(amount: amount, type: transactionType)
                            onSave(transaction)
                            dismiss()
                        }
                    }
                    .disabled(inputAmount.isEmpty)
                }
            }
        }
        .onAppear {
            if let editingTransaction = editingTransaction {
                inputAmount = String(format: "%.2f", editingTransaction.amount)
            }
        }
    }
}

// Transaction model
struct Transaction: Identifiable {
    let id = UUID()
    var amount: Double
    var type: TransactionType
    
    enum TransactionType {
        case credit
        case debit
    }
}

// Transaction row view
struct TransactionRowView: View {
    let transaction: Transaction

    var body: some View {
        HStack {
            Text(transaction.type == .credit ? "Credit" : "Debit")
                .font(.headline)
            Spacer()
            Text(transaction.amount, format: .currency(code: "USD"))
                .font(.subheadline)
                .foregroundColor(transaction.type == .credit ? .green : .red)
        }
        .padding(.vertical, 4)
    }
}

// Preview
struct CurrencyToolbarListView_Previews: PreviewProvider {
    static var previews: some View {
        CurrencyToolbarListView()
    }
}

