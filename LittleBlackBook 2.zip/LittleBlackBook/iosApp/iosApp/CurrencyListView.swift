//
//  CurrencyListView.swift
//  iosApp
//
//  Created by Adam Dahan on 2024-12-11.
//  Copyright © 2024 orgName. All rights reserved.
//

import SwiftUI

struct CurrencyListView: View {
    @State private var amount: Double = 100.00
    
    var body: some View {
        List {
            Section(header: CurrencyDisplayView(
                amount: amount
            )) {
                ForEach(1..<11, id: \.self) { item in
                    Text("Item \(item)")
                }
            }
        }
        .listStyle(InsetGroupedListStyle()) // Style for better appearance
    }
}
