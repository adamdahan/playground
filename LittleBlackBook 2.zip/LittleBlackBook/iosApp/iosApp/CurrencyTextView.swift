//
//  CurrencyTextView.swift
//  iosApp
//
//  Created by Adam Dahan on 2024-12-11.
//  Copyright © 2024 orgName. All rights reserved.
//

import Foundation
import SwiftUI

struct CurrencyDisplayView: View {
    var amount: Double
    
    var body: some View {
        ZStack {
            VStack {
                RoundedRectangle(cornerRadius: Constants.cornerRadius)
                    .fill(Color(amount == 0 ? UIColor.blue : amount > 0 ? UIColor.systemGreen : UIColor.systemRed))
                    .shadow(radius: Constants.shadowRadius)
                    .overlay(
                        CurrencyTextView(amount: amount)
                    )
                Spacer()
            }
        }
    }
}

private enum Constants {
    static let cornerRadius: CGFloat = 16
    static let shadowRadius: CGFloat = 4
    static let iconSize: CGFloat = 40
    static let buttonPadding: CGFloat = 16
}

struct CurrencyTextView: View {
    var amount: Double
    
    private var formattedAmount: String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencySymbol = Constants.currencySymbol
        formatter.maximumFractionDigits = Constants.maximumFractionDigits
        formatter.minimumFractionDigits = Constants.minimumFractionDigits
        return formatter.string(from: NSNumber(value: amount)) ?? Constants.defaultFormattedAmount
    }
    
    var body: some View {
        Text(formattedAmount)
            .font(.system(size: Constants.fontSize, weight: Constants.fontWeight, design: .default))
            .foregroundColor(.primary)
            .lineLimit(Constants.lineLimit)
            .minimumScaleFactor(Constants.minimumScaleFactor)
            .accessibilityLabel("Amount: \(formattedAmount)")
    }
}

private extension CurrencyTextView {
    enum Constants {
        static let currencySymbol = "$"
        static let maximumFractionDigits = 2
        static let minimumFractionDigits = 2
        static let defaultFormattedAmount = "$0.00"
        static let fontSize: CGFloat = 48
        static let fontWeight: Font.Weight = .bold
        static let lineLimit = 1
        static let minimumScaleFactor: CGFloat = 0.5
    }
}

struct CurrencyDisplayView_Previews: PreviewProvider {
    static var previews: some View {
        CurrencyDisplayView(amount: 200.00)
        .previewDevice("iPhone 14 Pro")
    }
}
